<div class="pui-col xs-4">
    <div class="chip sm">
        <? dynamic_sidebar('ستون سمت چپ'); ?>
    </div>
</div>