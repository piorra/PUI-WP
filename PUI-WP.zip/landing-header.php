<div class="landing-header">
    <div class="landing-content">
        <h2><?bloginfo('name')?></h2>
        <span><?bloginfo('description')?></span>
    </div>
    <!--    <button class="btn fab lg red"><i class="material-icons">exit_to_app</i></button>-->
</div>