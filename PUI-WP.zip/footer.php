</body>
<script src="<?=get_template_directory_uri();?>/assets/js/jquery.min.js"></script>
<script src="<?=get_template_directory_uri();?>/assets/js/pui.js"></script>
<script src="<?=get_template_directory_uri();?>/assets/js/ioScroll.min.js"></script>
<script src="<?=get_template_directory_uri();?>/assets/js/template.js"></script>
<script type="text/javascript">
        ioScroll.effect({
            scroll_offset:0,
            translate3d: 3
        }, $('.landing-content'))
    </script>
</html>
